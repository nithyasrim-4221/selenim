
import { useState } from "react";
import "./App.css";

function App() {
  const [students, setStudents] = useState([]);
  const [name, setName] = useState("");
  const [regno, setRegno] = useState("");
  const [course, setCourse] = useState("");
  const [editId, setEditId] = useState(null);

  // CREATE and UPDATE
  function saveStudent(e) {
    e.preventDefault();

    if (editId !== null) {
      setStudents(students.map((s) =>
        s.id === editId
          ? { id: editId, name, regno, course }
          : s
      ));
    } else {
      setStudents([...students, {
        id: Date.now(),
        name,
        regno,
        course
      }]);
    }

    clearForm();
  }

  // READ and EDIT
  function editStudent(s) {
    setName(s.name);
    setRegno(s.regno);
    setCourse(s.course);
    setEditId(s.id);
  }

  // DELETE
  function deleteStudent(id) {
    if (window.confirm("Delete this student?")) {
      setStudents(students.filter((s) => s.id !== id));
    }
  }

  function clearForm() {
    setName("");
    setRegno("");
    setCourse("");
    setEditId(null);
  }

  return (
    <div>
      <h2>Student Course Registration</h2>

      <h3>{editId !== null ? "Update Student" : "Register Student"}</h3>

      <form onSubmit={saveStudent}>
        <label>Student Name: </label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <br /><br />

        <label>Register Number: </label>
        <input
          value={regno}
          onChange={(e) => setRegno(e.target.value)}
          required
        />
        <br /><br />

        <label>Course: </label>
        <select
          value={course}
          onChange={(e) => setCourse(e.target.value)}
          required
        >
          <option value="">Select Course</option>
          <option value="B.Tech IT">B.Tech IT</option>
          <option value="Computer Science">Computer Science</option>
          <option value="Data Science">Data Science</option>
        </select>
        <br /><br />

        <button type="submit">
          {editId !== null ? "Update" : "Register"}
        </button>

        {editId !== null && (
          <button type="button" onClick={clearForm}>
            Cancel
          </button>
        )}
      </form>

      <hr />

      <h3>Registered Students</h3>

      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>Name</th>
            <th>Register Number</th>
            <th>Course</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {students.map((s) => (
            <tr key={s.id}>
              <td>{s.name}</td>
              <td>{s.regno}</td>
              <td>{s.course}</td>
              <td>
                <button onClick={() => editStudent(s)}>
                  Edit
                </button>
                <button onClick={() => deleteStudent(s.id)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
