
const express = require("express");
const app = express();

app.use(express.json());

let queue = [
  {
    id: 1,
    token: 1,
    customerName: "Hemalatha",
    service: "General Enquiry",
    counter: 1,
    status: "Completed"
  },
  {
    id: 2,
    token: 2,
    customerName: "Karthik",
    service: "Bill Payment",
    counter: 2,
    status: "Serving"
  },
  {
    id: 3,
    token: 3,
    customerName: "Nithya",
    service: "Account Service",
    counter: 3,
    status: "Waiting"
  }
];

app.get("/api/queue", (req, res) => {
  res.json(queue);
});

app.post("/api/queue", (req, res) => {
  const item = req.body;

  item.id = queue.length + 1;
  item.token = queue.length + 1;
  item.status = "Waiting";

  queue.push(item);

  res.status(201).json({
    message: "Queue token generated successfully",
    queue: item
  });
});

app.listen(4000, () => {
  console.log(
    "REST service running at http://localhost:4000/api/queue"
  );
});

