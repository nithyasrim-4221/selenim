
const http = require("http");
const soap = require("soap");

const service = {
  QueueService: {
    QueuePort: {
      GetQueue: function(args) {
        return {
          token: 2,
          customerName: "Karthik",
          service: "Bill Payment",
          counter: 2,
          status: "Serving"
        };
      }
    }
  }
};

const xml = `
<definitions
 xmlns="http://schemas.xmlsoap.org/wsdl/"
 xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/"
 xmlns:tns="http://localhost:4001/queueService"
 xmlns:xsd="http://www.w3.org/2001/XMLSchema"
 name="QueueService"
 targetNamespace="http://localhost:4001/queueService">

 <types>
  <xsd:schema targetNamespace="http://localhost:4001/queueService">
   <xsd:element name="GetQueueRequest">
    <xsd:complexType>
     <xsd:sequence>
      <xsd:element name="id" type="xsd:int"/>
     </xsd:sequence>
    </xsd:complexType>
   </xsd:element>
   <xsd:element name="GetQueueResponse">
    <xsd:complexType>
     <xsd:sequence>
      <xsd:element name="token" type="xsd:int"/>
      <xsd:element name="customerName" type="xsd:string"/>
      <xsd:element name="service" type="xsd:string"/>
      <xsd:element name="counter" type="xsd:int"/>
      <xsd:element name="status" type="xsd:string"/>
     </xsd:sequence>
    </xsd:complexType>
   </xsd:element>
  </xsd:schema>
 </types>

 <message name="GetQueueInput">
  <part name="parameters" element="tns:GetQueueRequest"/>
 </message>
 <message name="GetQueueOutput">
  <part name="parameters" element="tns:GetQueueResponse"/>
 </message>

 <portType name="QueuePortType">
  <operation name="GetQueue">
   <input message="tns:GetQueueInput"/>
   <output message="tns:GetQueueOutput"/>
  </operation>
 </portType>

 <binding name="QueueBinding" type="tns:QueuePortType">
  <soap:binding style="document"
   transport="http://schemas.xmlsoap.org/soap/http"/>
  <operation name="GetQueue">
   <soap:operation soapAction="GetQueue"/>
   <input><soap:body use="literal"/></input>
   <output><soap:body use="literal"/></output>
  </operation>
 </binding>

 <service name="QueueService">
  <port name="QueuePort" binding="tns:QueueBinding">
   <soap:address location="http://localhost:4001/queueService"/>
  </port>
 </service>
</definitions>
`;

const server = http.createServer((req, res) => {
  res.end("SOAP Server Running");
});

server.listen(4001, () => {
  soap.listen(server, "/queueService", service, xml);

  console.log(
    "SOAP service running at http://localhost:4001/queueService?wsdl"
  );
});


