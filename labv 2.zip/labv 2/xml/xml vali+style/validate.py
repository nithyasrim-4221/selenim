from lxml import etree

tree = etree.parse("employees.xml")
dtd = etree.DTD("employees.dtd")

if dtd.validate(tree):
    print("XML is VALID")
else:
    print("XML is INVALID")
    print(dtd.error_log)