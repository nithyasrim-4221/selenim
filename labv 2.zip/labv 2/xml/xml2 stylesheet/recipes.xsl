<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:output method="html" indent="yes"/>

    <xsl:template match="/">
        <html>
            <head>
                <title>My Recipe Book</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f2f7f2;
                        margin: 30px;
                    }
                    h1 {
                        text-align: center;
                        color: darkgreen;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        background-color: white;
                    }
                    th, td {
                        border: 1px solid gray;
                        padding: 12px;
                        text-align: left;
                    }
                    th {
                        background-color: lightgreen;
                    }
                </style>
            </head>
            <body>
                <h1>My Recipe Book</h1>
                <table>
                    <tr>
                        <th>Recipe Name</th>
                        <th>Category</th>
                        <th>Ingredients</th>
                        <th>Cooking Time</th>
                    </tr>
                    <xsl:for-each select="recipes/recipe">
                        <tr>
                            <td><xsl:value-of select="name"/></td>
                            <td><xsl:value-of select="category"/></td>
                            <td><xsl:value-of select="ingredients"/></td>
                            <td><xsl:value-of select="time"/></td>
                        </tr>
                    </xsl:for-each>
                </table>
            </body>
        </html>
    </xsl:template>

</xsl:stylesheet>
