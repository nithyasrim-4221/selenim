from lxml import etree

try:
    schema_doc = etree.parse("books.xsd")
    schema = etree.XMLSchema(schema_doc)
    xml_doc = etree.parse("books.xml")

    schema.assertValid(xml_doc)
    print("XSD validation successful!")

except Exception as e:
    print("Validation failed:", e)
